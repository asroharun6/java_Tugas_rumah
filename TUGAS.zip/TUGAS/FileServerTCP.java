import javax.swing.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FileServerTCP {
    private static final int PORT = 12345;
    private static final String DIRECTORY_PATH = "received_files";
    private static DefaultListModel<String> logModel;

    public static void main(String[] args) {
        createAndShowGUI();
        startServer();
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("TCP File Server");
        JList<String> logList = new JList<>();
        logModel = new DefaultListModel<>();
        logList.setModel(logModel);

        frame.getContentPane().add(new JScrollPane(logList));
        frame.setSize(500, 400);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private static void startServer() {
        ExecutorService pool = Executors.newFixedThreadPool(10);

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            logModel.addElement("Server berjalan di port " + PORT);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                logModel.addElement("Koneksi dari: " + clientSocket.getInetAddress());
                pool.execute(new ClientHandler(clientSocket));
            }
        } catch (IOException e) {
            e.printStackTrace();
            logModel.addElement("Server error: " + e.getMessage());
        }
    }

    private static class ClientHandler implements Runnable {
        private final Socket clientSocket;

        ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        public void run() {
            try {
                InputStream inputStream = clientSocket.getInputStream();
                File directory = new File(DIRECTORY_PATH);
                if (!directory.exists()) {
                    directory.mkdir();
                }

                String fileName = "received_" + System.currentTimeMillis();
                File file = new File(directory, fileName);

                try (FileOutputStream fileOutputStream = new FileOutputStream(file);
                     BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream)) {

                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = inputStream.read(buffer)) != -1) {
                        bufferedOutputStream.write(buffer, 0, bytesRead);
                    }
                }
                logModel.addElement("File diterima dan disimpan: " + fileName);
            } catch (IOException e) {
                e.printStackTrace();
                logModel.addElement("Error saat menerima file: " + e.getMessage());
            } finally {
                try {
                    clientSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
