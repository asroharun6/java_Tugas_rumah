import javax.swing.*;
import java.awt.Desktop;
import java.awt.event.*;
import java.io.*;
import java.net.Socket;

public class FileClientTCP {

    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 12345;
    private static final String LOCAL_DIRECTORY_PATH = "sent_files"; // Direktori lokal
    private static JFrame frame;
    private static File selectedFile;
    private static DefaultListModel<String> sentFilesModel;

    public static void main(String[] args) {
        createAndShowGUI();
    }

    private static void createAndShowGUI() {
        frame = new JFrame("TCP File Client");
        JButton openButton = new JButton("Pilih File");
        JButton sendButton = new JButton("Kirim File");
        JList<String> sentFilesList = new JList<>();
        sentFilesModel = new DefaultListModel<>();
        sentFilesList.setModel(sentFilesModel);

        openButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int returnValue = fileChooser.showOpenDialog(null);
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    selectedFile = fileChooser.getSelectedFile();
                    System.out.println("File dipilih: " + selectedFile.getAbsolutePath());
                }
            }
        });

        sendButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (selectedFile != null) {
                    try {
                        sendFile(selectedFile);
                    } catch (IOException ioException) {
                        JOptionPane.showMessageDialog(frame, "Gagal mengirim file: " + ioException.getMessage());
                        ioException.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Silakan pilih file terlebih dahulu!");
                }
            }
        });

        sentFilesList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 2) { // Double-click
                    int index = sentFilesList.locationToIndex(evt.getPoint());
                    if (index >= 0) {
                        String filePath = sentFilesList.getModel().getElementAt(index);
                        openFile(filePath);
                    }
                }
            }
        });

        JPanel panel = new JPanel();
        panel.add(openButton);
        panel.add(sendButton);
        panel.add(new JScrollPane(sentFilesList));
        frame.getContentPane().add(panel);
        frame.setSize(500, 400);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private static void sendFile(File file) throws IOException {
        File localDirectory = new File(LOCAL_DIRECTORY_PATH);
        if (!localDirectory.exists()) {
            localDirectory.mkdir();
        }

        File localFile = new File(localDirectory, file.getName());

        try (Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
             FileInputStream fileInputStream = new FileInputStream(file);
             FileOutputStream fileOutputStream = new FileOutputStream(localFile);
             OutputStream outputStream = socket.getOutputStream()) {

            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
                fileOutputStream.write(buffer, 0, bytesRead);
            }

            sentFilesModel.addElement(localFile.getAbsolutePath());
        }
    }

    private static void openFile(String filePath) {
        try {
            File file = new File(filePath);
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(file);
            } else {
                JOptionPane.showMessageDialog(frame, "Desktop tidak didukung.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error saat membuka file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
